# Underchargers HR PWA — Phase 3 (Frontend Prototype)

Full repository replacement package for uploading **the contents of this directory** to your GitHub repository root, then deploying with Vercel (Next.js preset).

Phase 1: application shell, demo login, dashboards, grouped activity view. Phase 2: Employee 201 Files frontend. Phase 3: Recruitment & Hiring frontend (candidate pipeline, mock applicant entry, screening stages, requirement statuses, Google Forms placeholder).

## Deployment
- GitHub: upload extracted contents, not ZIP. Keep `package.json` at repository root.
- Vercel: framework `Next.js`, root directory `./`, no environment variables needed for prototype.
- Do not upload `node_modules` or sensitive records.
- Build commands: `npm install`, `npm run build`.

## Limitations
Data is mock/in-memory and resets on refresh. Usernames/passwords are visible in frontend source; **demo only**, never for live confidential HR use. Google Forms integration, real signing, Supabase, server permissions and audit trail will come in later phases.

See `docs/PHASE-3-CHECKLIST.md` for feature checklist and provisional database blueprint.
